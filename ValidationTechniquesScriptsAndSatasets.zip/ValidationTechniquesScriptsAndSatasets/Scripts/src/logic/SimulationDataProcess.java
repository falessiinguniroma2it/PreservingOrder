package logic;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class SimulationDataProcess {
	public static void startDatasetProcess(boolean pre) throws IOException
	{
		//is pre set to true, preprocess is needed to add Nsmell column and sum column S to UL
		if (pre)
		{
			preprocesses();
		}
		
		File [] listOfCSV = new File ("/home/jacky/weka/Datasets/").listFiles();
		for (File f : listOfCSV)
		{
			System.out.print("making new CSV based on versions ... ");
			ArrayList<String> versions = findNumVersions(f);
			System.out.print("found: " + versions.size() + "\n");
			makeNewFiles(versions, f);
			System.out.println("Done pre processing: " + f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().indexOf(".")));
		}
	}
	
	public static ArrayList<String> findNumVersions(File f) throws IOException
	{
		System.out.print("finding number of versions ... ");
		String currVersion = "";
		ArrayList<String> versions = new ArrayList<String>();
		BufferedReader br = new BufferedReader(new FileReader(f));
		boolean header = true;
		
		while(br.ready())
		{
			String [] temp = br.readLine().split(",");
			if (header)
			{
				header = false;
			}
			else 
			{
				if (!currVersion.equals(temp[0]))
				{
					currVersion = temp[0];
					versions.add(currVersion);
				}
			}
		}
		
		br.close();
		return versions;
	}
	
	private static void makeNewFiles(ArrayList<String> versions, File f) throws IOException
	{
		System.out.println("making new files...");
		String dataSetName = f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().indexOf("."));
		if (versions.size() > 2)
		{
			for (int i = 3; i <= versions.size(); i++)
			{
				ArrayList<String> tempVersions = new ArrayList<String>(versions.subList(0, i));
				createFile(tempVersions, dataSetName, f);
			}
		}
		else
		{
			return;
		}	
	}
	
	private static void createFile(ArrayList<String> versions, String dataSetName, File f) throws IOException
	{
		String destionationPath = "/home/jacky/weka/ProcessedDatasets/";
		System.out.println("creating new files ..." + destionationPath + dataSetName + "_" + versions.size() +".csv");
		FileWriter fw = new FileWriter(new File(destionationPath + dataSetName + "_" + versions.size() +".csv"), true);
		BufferedReader br = new BufferedReader(new FileReader(f));
		boolean header = true;
		
		while(br.ready())
		{
			String line = br.readLine();
			//System.out.println(line);
			if (header)
			{
				fw.write(line + "\n");
				header = false;
			}
			else 
			{
				if (versions.contains(line.split(",")[1]))
				{
					fw.write(line + "\n");
				}
			}
		}
		
		br.close();
		fw.close();
	}

	//pre process with max's data
	public static void preprocesses() throws IOException
	{
		clearFiles();
		File [] fileList = new File ("/home/jacky/weka/PreprocessedDatasets/").listFiles();
		Arrays.sort(fileList);
		boolean header = true;
		for (File f : fileList)
		{
			header = true;
			String datasetName = f.toString().substring(f.toString().lastIndexOf("/")+1, f.toString().lastIndexOf("."));
			System.out.println("Data Preparation: seperating dataset: " + datasetName);
			BufferedReader inputBF = new BufferedReader(new FileReader(f.toString()));
			while (inputBF.ready())
			{
				FileWriter fw = new FileWriter(new File("/home/jacky/weka/Datasets/" + datasetName + ".csv"), true);

				String line = inputBF.readLine();
				String [] data = line.split(",");
				for (int i = 0; i < data.length; i++)
				{
					data[i] = data[i].substring(1, data[i].lastIndexOf("\""));
				}
				String [] newData = new String [20];
				double tempSum = 0;
				if (header)
				{		
					String newHeader = "";
					for (int i = 0; i< 18; i++)
					{
						newHeader += data[i];
						newHeader += ",";
					}
					newHeader += "NSmells,";
					newHeader += data[data.length-1];
					newHeader += "\n";
					
					fw.append(newHeader);
					
					header = false;
				}
				else
				{
					for (int x = 18; x < data.length-1; x++)
					{
						tempSum += Double.valueOf(data[x]);
					}
					for(int i = 0; i<newData.length; i++)
					{
						if(i == newData.length-2)
						{
							newData[i] = String.valueOf(tempSum);
						}
						else if (i == newData.length-1)
						{
							newData[i] = data[data.length-1];
						}
						else
						{
							newData[i] = data[i];
						}
					}
					fw.append((String.join(",", newData)+"\n"));
				}
				fw.close();
			}
			header = true;
			inputBF.close();
		}
		System.out.println("Data Preparation: pre-process finished.");
	}
	
	private static void clearFiles()
	{
		File [] fileList = new File ("/home/jacky/weka/Datasets/").listFiles();
		File [] pFileList = new File ("/home/jacky/weka/ProcessedDatasets/").listFiles();

		for (File f : fileList)
		{
			f.delete();
		}
		for (File f : pFileList)
		{
			f.delete();
		}
		System.out.println("Data Preparation: Clearing out old files.");
	}
}
