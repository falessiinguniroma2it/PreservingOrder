package test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestIntermediate3.class, TestRQ1.class, TestRQ2.class, TestRQ4.class, TestRQ3meta.class, TestAccuracyD.class, TestSimulationDataProcess.class, TestSortResults.class })
public class SURPTestSuite {

}
