package test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import org.junit.Test;

import logic.SortResults;
import logic.SortResults.dataPoint;

public class TestSortResults {
	
	@Test
	public void test_findMedian()
	{
		double [] vals = {1.1, 1.1, 2.2};
		double [] vals2 = {1.1, 2.2, 2.2, 2.2};
		
		assertEquals(1.1, SortResults.findMedian(vals), 0.1);
		assertEquals(2.2, SortResults.findMedian(vals2), 0.1);
	}
	
	@Test
	public void test_buildHeader()
	{
		assertEquals("Dataset,Model,Holdout 0.5,Holdout 0.7,Repeated Holdout 0.5,Repeated Holdout 0.7,2-fold,10-fold,10x10-fold,Ordinary,Optimism-reduced,out-of-sample,0.632 Bootstrap,Leave-one-release-out,ActualAccuracy\n", SortResults.buildHeader("rq2int"));
	}
	
	@Test
	public void test_buildHeader2()
	{
		assertEquals("Dataset,Model,Holdout 0.5,Holdout 0.7,Repeated Holdout 0.5,Repeated Holdout 0.7,2-fold,10-fold,10x10-fold,Ordinary,Optimism-reduced,out-of-sample,0.632 Bootstrap,Leave-one-release-out,Model Accuracy on D\n", SortResults.buildHeader("rq3int"));
	}
	
	@Test
	public void test_buildHeader3()
	{
		assertEquals("Dataset,Model,Mean of Techniques,Median of Techniques,ActualAccuracy\n", SortResults.buildHeader("rq3uns"));
	}
	
	@Test
	public void test_buildHeader4()
	{
		assertEquals("Dataset,Mean of Techniques,Median of Techniques,Best\n", SortResults.buildHeader("rq3final"));
	}
	
	@Test
	public void test_buildHeader5()
	{
		assertEquals("Dataset,Best Technique AUC,Best Technique Precision,Best Technique Recall\n", SortResults.buildHeader("rq3intbest"));
	}
	
	@Test
	public void test_buildEntry1()
	{
		SortResults.dataPoint d = new SortResults.dataPoint("Keymind-B", "RandomForest", 1.1, 2.2, 3.3);
		double [] vals = {1.1, 1.1, 2.2};
		double actual = 3.3;
		
		assertEquals("Keymind-B,RandomForest,1.1,1.1,2.2,3.3\n", SortResults.buildEntry(d, vals, actual));
	}

	@Test
	public void test_buildEntry2()
	{
		double [] vals = {1.1, 1.1, 2.2};
		String name = "Keymind-B";
		
		assertEquals("Keymind-B,1.1,1.1,2.2\n", SortResults.buildEntry(name, vals));
	}
	@Test
	public void test_buildEntry3()
	{
		assertEquals("Keymind-B,RandomForest,1.1,2.2,3.3\n", SortResults.buildEntry("Keymind-B", "RandomForest", 1.1, 2.2, 3.3));
	}
	@Test
	public void test_buildEntry4()
	{
		assertEquals("Keymind-B,1.1,2.2,3.3\n", SortResults.buildEntry("Keymind-B", 1.1, 2.2, 3.3));
	}
	@Test
	public void test_buildEntry5()
	{
		String [] data = {"test1", "test2", "test3", "test4", "2345768"};
		assertEquals("test1,test2,test3,test4,2345768,\n", SortResults.buildEntry(data));
	}
	
	private boolean checkedDP(SortResults.dataPoint A, SortResults.dataPoint B)
	{
		return A.datasetName.equals(B.datasetName) &&
				A.Model.equals(B.Model) &&
				A.auc == B.auc &&
				A.precision == B.precision &&
				A.recall == B.recall;
	}
	
	@Test
	public void test_findDP() throws FileNotFoundException, IOException
	{
		ArrayList<dataPoint> rq1 = SortResults.buildData(new BufferedReader(new FileReader("/home/jacky/eclipse-workspace/SURP/TestResources/RQ1-Results-short.csv")));
		Collections.sort(rq1);
		
		SortResults.dataPoint d = new SortResults.dataPoint("Keymind-A_3", "RandomForest", 0.609, 0.197, 0.477);
		
		assertTrue(checkedDP(d, SortResults.findDP(rq1, d)));
	}
	
	@Test
	public void test_findBestAUC() throws IOException
	{
		File [] rq3FileList = new File ("/home/jacky/weka/Analyzed-Results/rq3-int").listFiles();
		Arrays.sort(rq3FileList);
		
		String [][] table = SortResults.fillBestTechniqueTable(rq3FileList, 36);
		
		assertEquals(0.747, SortResults.findBestAUC("Keymind-A_3", table), 0.1);
	}
	
	@Test
	public void test_findBestIndex() throws IOException
	{
		double [][] table = SortResults.buildTable(new File("/home/jacky/weka/Analyzed-Results/rq2-int/Keymind-A_3_A_Rq2-int.csv"));
		int [] ind = {0, 0, 0, 0, 1, 2, 7, 0, 0, 0, 0, 2 };
		
		assertArrayEquals(ind, SortResults.findBestIndex(table));
	}
	
	@Test
	public void test_findBest() throws IOException
	{
		double [][] table = SortResults.buildTable(new File("/home/jacky/weka/Analyzed-Results/rq2-int/Keymind-A_3_A_Rq2-int.csv"));
		double [] vals = {0.609, 0.609, 0.609, 0.609, 0.747, 0.75, 0.756, 0.609, 0.609, 0.609, 0.609, 0.75};
		
		assertTrue(Arrays.equals(vals, SortResults.findBest(table)));
	}
	
	
	@Test
	public void test_findBest2() throws IOException
	{		
		assertEquals("2-fold", SortResults.findBest(new File("/home/jacky/weka/Analyzed-Results/rq3-int/Keymind-A_3_A_Rq3-int-best.csv")));
	}
	
	@Test
	public void test_buildTable() throws IOException
	{
		double [][] table = {{0.876, 0.934, 0.872, 0.947, 0.7, 0.627, 0.599, 0.921, 0.917, 0.898, 0.913, 0.626,0.609},
		{0.698,	0.713,	0.693,	0.696,	0.731,	0.569,	0.703,	0.692,	0.706,	0.679,	0.692,	0.647,	0.747},
		{0.687,	0.678,	0.669,	0.676,	0.726,	0.661,	0.739,	0.671,	0.677,	0.621,	0.671,	0.676,	0.75},
		{0.715,	0.756,	0.746,	0.761,	0.679,	0.61,	0.572,	0.793,	0.756,	0.794,	0.784,	0.66,	0.548},
		{0.7,	0.726,	0.695,	0.731,	0.644,	0.566,	0.489,	0.725,	0.753,	0.684,	0.732,	0.581,	0.691},
		{0.688,	0.703,	0.684,	0.696,	0.612,	0.57, 0.489,	0.694,	0.715,	0.672,	0.698,	0.55,	0.626},
		{0.541, 0.554,	0.541,	0.543,	0.558,	0.5,	0.478,	0.542,	0.533,	0.544,	0.545,	0.525,	0.62},
		{0.674,	0.668,	0.711,	0.696,	0.709,	0.644,	0.834,	0.687,	0.678,	0.662,	0.691,	0.675,	0.756},
		{0.692,	0.691,	0.708,	0.69, 0.715,	0.616,	0.822,	0.702,	0.702,	0.656,	0.701,	0.66,	0.709}};

		assertTrue(Arrays.deepEquals(table, SortResults.buildTable(new File("/home/jacky/weka/Analyzed-Results/rq2-int/Keymind-A_3_A_Rq2-int.csv"))));
	}
	
	@Test
	public void test_fillBestTechniqueTable() throws Exception
	{
		String [][] table = {{"Keymind-A_3", "2-fold", "Repeated Holdout 0.7", "2-fold"},
				{"Keymind-A_4", "10x10-fold", "Optimism-reduced", "2-fold"}, 
				{"Keymind-A_5", "Repeated Holdout 0.7", "2-fold", "2-fold"},
				{"Keymind-B_3", "Repeated Holdout 0.7", "Optimism-reduced", "2-fold"}, 
				{"Keymind-B_4", "Optimism-reduced", "Repeated Holdout 0.7", "Leave-one-release-out"}, 
				{"Keymind-B_5", "Optimism-reduced", "2-fold", "10x10-fold"}, 
				{"ant_3", "2-fold", "Repeated Holdout 0.7", "0.632 Bootstrap"}, 
				{"ant_4", "2-fold", "10-fold", "Repeated Holdout 0.7"}, 
				{"ant_5", "2-fold", "2-fold", "10x10-fold"}, 
				{"ar_3", "Holdout 0.7", "Repeated Holdout 0.7", "2-fold"}, 
				{"ar_4", "2-fold", "Repeated Holdout 0.7", "10x10-fold"},
				{"ar_5", "2-fold", "Holdout 0.5", "10x10-fold"}, 
				{"camel_3", "Repeated Holdout 0.7", "Repeated Holdout 0.7", "10x10-fold"},
				{"camel_4", "Repeated Holdout 0.7", "10-fold", "10x10-fold"},
				{"eclipse_3", "2-fold", "Leave-one-release-out", "Holdout 0.7"},
				{"forrest_3", "2-fold", "Ordinary", "Holdout 0.7"}, 
				{"ivy_3", "10x10-fold", "10-fold", "2-fold"}, 
				{"jedit_3", "Optimism-reduced", "Optimism-reduced", "Repeated Holdout 0.7"}, 
				{"jedit_4", "Repeated Holdout 0.7", "out-of-sample", "10x10-fold"}, 
				{"jedit_5", "10x10-fold", "Holdout 0.7", "2-fold"},
				{"log4j_3", "10-fold", "10x10-fold", "10x10-fold"}, 
				{"lucene_3", "Repeated Holdout 0.7", "Holdout 0.7", "Holdout 0.5"},
				{"poi_3", "Leave-one-release-out", "Leave-one-release-out", "2-fold"}, 
				{"poi_4", "2-fold", "2-fold", "Optimism-reduced"},
				{"prop_3", "10-fold", "10x10-fold", "Leave-one-release-out"}, 
				{"prop_4", "10x10-fold", "2-fold", "Holdout 0.7"},
				{"prop_5", "10-fold", "Holdout 0.7", "Repeated Holdout 0.7"}, 
				{"prop_6", "10x10-fold", "Holdout 0.7", "10x10-fold"}, 
				{"prop_7", "10x10-fold", "10x10-fold", "Repeated Holdout 0.5"},
				{"prop_8", "2-fold", "Leave-one-release-out", "10x10-fold"}, 
				{"prop_9", "Repeated Holdout 0.7", "10x10-fold", "10x10-fold"}, 
				{"synapse_3", "Leave-one-release-out", "Leave-one-release-out", "Optimism-reduced"},
				{"velocity_3", "Leave-one-release-out", "Optimism-reduced", "10x10-fold"}, 
				{"xalan_3", "10-fold", "2-fold", "10x10-fold"},
				{"xalan_4", "Holdout 0.7", "10x10-fold", "10x10-fold"},
				{"xerces_3", "Holdout 0.7", "10x10-fold", "Repeated Holdout 0.7"}};
					
		File [] rq3FileList = new File ("/home/jacky/weka/Analyzed-Results/rq3-int").listFiles();
		Arrays.sort(rq3FileList);
		
		assertTrue(Arrays.deepEquals(table, SortResults.fillBestTechniqueTable(rq3FileList, 36)));
	}
	
	private boolean checkedList(ArrayList<dataPoint> A, ArrayList<dataPoint> B)
	{
		for (int i = 0; i < A.size(); i++)
		{
			if (!A.get(i).equal(B.get(i)))
			{
				return false;
			}
		}
		return true;
	}
	
	@Test
	public void test_buildData() throws FileNotFoundException, IOException
	{
		ArrayList<dataPoint> res = new ArrayList<dataPoint>();
		res.add(new SortResults.dataPoint("Keymind-A_3", "RandomForest", 0.609, 0.197, 0.477));
		res.add(new SortResults.dataPoint("Keymind-A_3", "Logistic", 0.747, 0.36, 0.429));
		res.add(new SortResults.dataPoint("Keymind-A_3", "NaiveBayes", 0.75, 0.259, 0.381));

		assertTrue(checkedList(res, SortResults.buildData(new BufferedReader(new FileReader("/home/jacky/eclipse-workspace/SURP/TestResources/RQ1-Results-short.csv")))));
	}
}
