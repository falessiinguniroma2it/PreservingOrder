package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.Test;

import logic.RQ3meta;
import logic.TechniqueRes;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.CSVLoader;

public class TestRQ3meta {
	
	private Instances getData(File f) throws IOException
	{
		CSVLoader csvload = new CSVLoader();
		csvload.setSource(f);
		Instances data = csvload.getDataSet();
		
		return data;
	}
	
	private boolean checkData(Instances A, Instances B)
	{
		if (A.numInstances() != B.numInstances())
		{
			return false;
		}
		else
		{
			for(int i = 0; i < A.numInstances(); i++)
			{
				if(!A.get(i).toString().equals(B.get(i).toString()))
				{
					return false;
				}
			}
		}
		return true;
	}
	
	@Test
	public void test_findAverage()
	{
		double [] vals = {1.0, 2.0, 3.0, 4.0, 5.0};
		
		assertEquals(3.0, RQ3meta.findAverage(vals, 5), 0.0);
	}
	
	@Test
	public void test_outOfSampleData() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instances train = RQ3meta.seperateDataset(data, "1011", true);
		Instances test = RQ3meta.seperateDataset(data, "1011", false);
		Instances newTest = RQ3meta.outOfSampleData(data, train);
		
		assertTrue(checkData(test, newTest));
	}
	
	@Test
	public void test_findNumVersions() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		ArrayList<String> versions = new ArrayList<String>();
		versions.add("100");
		versions.add("102");
		versions.add("104");
		versions.add("107");
		versions.add("1011");
		
		assertEquals(versions, RQ3meta.findNumVersions(data));
	}
	
	@Test
	public void test_findPositiveClassIndex() throws IOException 
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		assertEquals(1, RQ3meta.findPositiveClassIndex(data));
	}
	
	@Test
	public void test_seperateDataset_train() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instances train = RQ3meta.seperateDataset(data, "1011", true);
		
		boolean checked = true;
		for (Instance i : train)
		{
			if (i.toString(0).equals("1011"))
			{
				checked = false;
				break;
			}
		}
		assertTrue(checked);
	}
	
	@Test
	public void test_seperateDataset_test() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instances test = RQ3meta.seperateDataset(data, "1011", false);
		
		boolean checked = true;
		for (Instance i : test)
		{
			if (!i.toString(0).equals("1011"))
			{
				checked = false;
				break;
			}
		}
		assertTrue(checked);
	}
	
	@Test
	public void test_buildEntryOne() 
	{
		assertEquals("Keymind-B_2,RandomForest,Hold out 0.5,1\n", RQ3meta.buildEntryOne("Keymind-B_2", "RandomForest", "Hold out 0.5", 1.0));
	}
	
	@Test
	public void test_removeAttribute() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		data = RQ3meta.removeAttribute(data);
		
		assertEquals("3,0,1,1,14,7,7,14,7,7,18,7,6,25,?,2,14,2,0,15,43,43,98,FALSE", data.get(0).toString());
	}
	
	@Test
	public void test_findLastRelease() throws IOException
	{
		File f = new File("/home/jacky/eclipse-workspace/SURP/TestResources/ant.csv");
		CSVLoader csvload = new CSVLoader();
		csvload.setSource(f);
		Instances data = csvload.getDataSet();
		
		assertEquals("1.7", RQ3meta.findLastRelease(data));
	}
	
	@Test
	public void test_csv2arff () throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));

		RQ3meta.csv2arff(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"), false);
		Instances newData = new Instances(new FileReader("/home/jacky/weka/modifiedDatasets/Keymind-B.arff"));

		assertTrue(checkData(data, newData));
	}
	
	@Test
	public void test_csv2arff_special () throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/poi.csv"));

		RQ3meta.csv2arff(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/poi.csv"), true);
		Instances newData = new Instances(new FileReader("/home/jacky/weka/modifiedDatasets/poi.arff"));

		assertTrue(checkData(data, newData));
	}
	
	private boolean checkBest(double [] A, double [] B)
	{
		for(int i = 0; i<A.length; i++)
		{
			if(A[i] != B[i])
			{
				return false;
			}
		}
		return true;
	}
	
	@Test
	public void test_intermediateFive()
	{
		String dataSetName = "Keymind-B_2";
		ArrayList<String>intermediateAUCD = new ArrayList<String>();
		
		intermediateAUCD.add("1.0");
		intermediateAUCD.add("2.0");
		
		assertEquals("Holdout 0.7", RQ3meta.intermediateFive(dataSetName, intermediateAUCD));
	}
	
	@Test
	public void test_intermedaiteTwo()
	{
		String dataSetName = "Keymind-B_2";
		String thq = "Holdot 0.5";
		ArrayList<Double>intermedateVals = new ArrayList<Double>();
		
		intermedateVals.add(1.0);
		intermedateVals.add(2.0);
		
		assertEquals("Logistic", RQ3meta.intermedaiteTwo(dataSetName, thq, intermedateVals));
	}

	@Test
	public void test_intermediateFour()
	{
		String choosenModel = "Logistic";
		ArrayList<String> intermediateAUC3 = new ArrayList<String>();
		
		intermediateAUC3.add("1.0");
		intermediateAUC3.add("2.0");
		
		assertEquals("2.0", RQ3meta.intermediateFour(choosenModel, intermediateAUC3));
	}
	
	
}
