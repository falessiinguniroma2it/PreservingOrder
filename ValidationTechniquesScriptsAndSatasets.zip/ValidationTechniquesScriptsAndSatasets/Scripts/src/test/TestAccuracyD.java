package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.junit.Test;

import logic.AccuracyD;
import logic.TechniqueRes;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.CSVLoader;

public class TestAccuracyD {
	
	private Instances getData(File f) throws IOException
	{
		CSVLoader csvload = new CSVLoader();
		csvload.setSource(f);
		Instances data = csvload.getDataSet();
		
		return data;
	}
	
	private boolean checkData(Instances A, Instances B)
	{
		if (A.numInstances() != B.numInstances())
		{
			return false;
		}
		else
		{
			for(int i = 0; i < A.numInstances(); i++)
			{
				if(!A.get(i).toString().equals(B.get(i).toString()))
				{
					return false;
				}
			}
		}
		return true;
	}
	
	@Test
	public void test_findNumVersions() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		
		assertEquals(5, AccuracyD.findNumVersions(data));
	}
	
	@Test
	public void test_findPositiveClassIndex() throws IOException 
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		assertEquals(1, AccuracyD.findPositiveClassIndex(data));
	}
	
	@Test
	public void test_removeAttribute() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		data = AccuracyD.removeAttribute(data);
		
		assertEquals("3,0,1,1,14,7,7,14,7,7,18,7,6,25,?,2,14,2,0,15,43,43,98,FALSE", data.get(0).toString());
	}
	
	@Test
	public void test_seperateDataset_train() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instances train = AccuracyD.seperateDataset(data, "1011", true);
		
		boolean checked = true;
		for (Instance i : train)
		{
			if (i.toString(0).equals("1011"))
			{
				checked = false;
				break;
			}
		}
		assertTrue(checked);
	}
	
	@Test
	public void test_seperateDataset_test() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instances test = AccuracyD.seperateDataset(data, "1011", false);
		
		boolean checked = true;
		for (Instance i : test)
		{
			if (!i.toString(0).equals("1011"))
			{
				checked = false;
				break;
			}
		}
		assertTrue(checked);
	}
	
	@Test
	public void test_findLastRelease() throws IOException
	{
		File f = new File("/home/jacky/eclipse-workspace/SURP/TestResources/ant.csv");
		CSVLoader csvload = new CSVLoader();
		csvload.setSource(f);
		Instances data = csvload.getDataSet();
		
		assertEquals("1.7", AccuracyD.findLastRelease(data));
	}
	
	@Test
	public void test_buildEntry()
	{
		assertEquals("Keymind-B,RandomForest,1.1,2.2,3.3\n", AccuracyD.buildEntry("Keymind-B", "RandomForest", 1.1, 2.2, 3.3));
	}
	
	@Test
	public void test_buildHeader()
	{	
		assertEquals("Dataset,Model,AUC,Precision,Recall\n", AccuracyD.buildHeader());
	}
	
	@Test
	public void test_csv2arff () throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));

		AccuracyD.csv2arff(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
		Instances newData = new Instances(new FileReader("/home/jacky/weka/modifiedDatasets/Keymind-B.arff"));

		assertTrue(checkData(data, newData));
	}
	
	@Test
	public void test_csv2arff_special () throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/poi.csv"));

		AccuracyD.csv2arff(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/poi.csv"), true);
		Instances newData = new Instances(new FileReader("/home/jacky/weka/modifiedDatasets/poi.arff"));

		assertTrue(checkData(data, newData));
	}
	
	@Test
	public void test_Model() throws Exception
	{
		Instances data = getData(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv"));
    	data.setClassIndex(data.numAttributes() -1 );
		TechniqueRes r = new TechniqueRes(1.0, 0.8333333333333334, 1.0);
		
		assertTrue(checkedRes(r, AccuracyD.Model(data, "RandomForest")));
	}

	private boolean checkedRes(TechniqueRes A, TechniqueRes B)
	{
		return A.auc == B.auc &&
				A.recall == B.recall &&
				A.precision == B.precision;
	}
}
