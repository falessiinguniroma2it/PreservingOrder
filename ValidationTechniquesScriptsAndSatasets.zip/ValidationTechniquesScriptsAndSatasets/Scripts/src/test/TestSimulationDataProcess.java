package test;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.util.ArrayList;

import org.junit.Test;

import logic.SimulationDataProcess;
import weka.core.Instances;

public class TestSimulationDataProcess {

	@Test
	public void test_findNumVersions() throws Exception
	{
		ArrayList<String> versions = new ArrayList<String>();
		versions.add("100");
		versions.add("102");
		versions.add("104");
		versions.add("107");
		versions.add("1011");
		
		assertEquals(versions, SimulationDataProcess.findNumVersions(new File ("/home/jacky/eclipse-workspace/SURP/TestResources/Keymind-B.csv")));
	}
}
